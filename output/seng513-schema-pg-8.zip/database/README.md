# FinClear database schema and seed

SENG 513 - Group 8

## Included files

- `database/schema.sql` creates tables, relationships, indexes and reporting views.
- `database/seed.sql` loads fictional development data.
- `database/verify.sql` checks demo totals and database constraints, then rolls back its changes.
- `database/README.md` contains these instructions.
- `output/pdf/seng513-schema-pg-8.pdf` is a PDF copy of these instructions.

## 1. Prepare the environment

Install Git and Docker Desktop with Docker Compose, then start Docker Desktop. Run commands from the repository root.

```bash
git clone https://csgit.ucalgary.ca/seng513f26/pg-8/seng513-202604-pg-8.git
cd seng513-202604-pg-8
cp .env.example .env
```

If you already have a checkout and `.env`, use them. Set `POSTGRES_PASSWORD` in `.env` to your local database password. The `.env` file is ignored by Git. Use separate credentials for production.

```bash
docker compose config --quiet
docker compose up -d --build
docker compose exec database pg_isready -U seng513 -d seng513
```

Wait until `pg_isready` reports that it is accepting connections. Repeat that command if PostgreSQL is still starting. PostgreSQL 15 or newer is required. The Compose configuration uses PostgreSQL 15.

## 2. Create the schema

```bash
docker compose exec -T database psql -U seng513 -d seng513 \
  -v ON_ERROR_STOP=1 < database/schema.sql
```

The script creates the schema in the database's default `public` schema. It runs in a transaction and stops on errors. It can be rerun against the same schema version without deleting data. Later structural changes should be delivered as migrations. `CREATE TABLE IF NOT EXISTS` does not upgrade incompatible existing tables.

The scripts take the same PostgreSQL advisory lock to serialize schema and seed runs. They use psql commands, so execute them with psql rather than passing their complete contents to `pool.query()`.

## 3. Load the development seed

```bash
docker compose exec -T database psql -U seng513 -d seng513 \
  -v ON_ERROR_STOP=1 < database/seed.sql
```

The seed uses fixed UUIDs and `ON CONFLICT DO NOTHING`. Reruns skip existing records and preserve edits to those records. Deleted demo rows are inserted again if their identifiers are available. The seed does not reset an edited workspace. It includes historical August, September and October 2026 transactions, so select October 2026 when comparing the demo with the UI.

The four fictional users are David Lee (trial), Morgan Watson (premium), Sarah Larson (guest) and Alex Chen (free). Registered demo emails are `david@example.com`, `morgan@example.com` and `alex@example.com`. Their shared development password is `FinClearDemo!2026`. Sarah's guest workspace has no email or password.

Passwords are stored as scrypt hashes using the format `scrypt$N$r$p$saltHex$derivedKeyHex`, with N=16384, r=8, p=1, a 16-byte salt and a 64-byte derived key. An authentication implementation can verify these with Node's `crypto.scrypt` and `crypto.timingSafeEqual`. The existing backend currently exposes health endpoints. The seeded credentials become usable for login when authentication is implemented.

Guest rows represent isolated sample workspaces. The backend must create or associate the correct workspace with a guest session, and must filter all queries by the authenticated user's ID. Role permissions, trial expiration and account limits must be enforced in the backend. Foreign keys enforce ownership relationships within the stored data.

## 4. Verify the database

```bash
docker compose exec -T database psql -U seng513 -d seng513 \
  -v ON_ERROR_STOP=1 < database/verify.sql
curl http://localhost:3001/db-health
```

The SQL checks print `All schema acceptance checks passed`. Verification uses a transaction that rolls back its temporary inserts and updates. It assumes the original demo amounts and roles remain intact. The backend should return `{"database":"connected"}`.

Inspect budget groups for David using a read-only query.

```bash
docker compose exec -T database psql -U seng513 -d seng513 <<'SQL'
SELECT group_name, allocated_amount, actual_spending, remaining
FROM budget_group_spending
WHERE user_id = '10000000-0000-0000-0000-000000000001'
ORDER BY group_name;
SQL
```

Expected October values are Home & bills 1650 allocated and 1200 spent, Food & drink 950 allocated and 630 spent, Transportation 200 allocated and 90 spent, Shopping 500 allocated and 60 spent, and Subscriptions 300 allocated and 60 spent. Total planned spending is 3600, actual spending is 2040, and remaining allowance is 1560 CAD. Expected income is 4200 and reserved savings is 600 CAD. Groceries is 510 of its 600 budget, or 85 percent.

Inspect Morgan's business cash flow.

```bash
docker compose exec -T database psql -U seng513 -d seng513 <<'SQL'
SELECT month, money_in, money_out, money_in - money_out AS net_cash_flow
FROM monthly_cash_flow
WHERE user_id = '10000000-0000-0000-0000-000000000002'
  AND scope = 'business';
SQL
```

Expected October values are 8400 CAD in, 5150 CAD out and 3250 CAD net. His personal expenses are excluded. David's emergency fund has 1800 CAD contributed toward a 5000 CAD goal.

## 5. Model and relationships

`users` owns the workspace data. `user_settings` is one-to-one with a user. `notification_preferences` has one row per user and event type. The access roles are guest, free, trial and premium. Free is included because the Figma plan comparison offers a Free plan after the trial.

`bank_connections` has many `accounts`. A connection stores institution, provider item ID, sync cursor, status and last sync time. `access_token_secret_ref` is a reference to a token in an external secret store. Seed connections use the sample provider and contain no real Plaid tokens. Manual accounts have no connection. Accounts store their type, personal/business scope, four-digit mask, currency, bank balance snapshot and archive timestamp. An unavailable balance is NULL. Credit card and loan balances represent amounts owed.

`category_groups` has many `categories`. For example, Home & bills contains Rent, Phone and Wi-Fi. Each user owns their categories. Categories can be archived while preserving transaction history. A category without a visible breakdown uses one leaf category within its group.

`accounts` has many `transactions`. Each transaction references the current category and optionally the original imported category. The backend updates `category_id` and `category_overridden` when a user changes categorization, and preserves the original category. Provider IDs prevent duplicate imports within an account. Pending IDs support reconciliation when a pending purchase posts. The sync implementation must reconcile pending-to-posted transitions, mark removed transactions and preserve user overrides on subsequent imports.

`budgets` is unique per user, month, scope and currency. `budget_allocations` assigns a limit to each selected category. Groups are calculated from leaf allocations, avoiding double-counting. A replacement plan updates the budget and allocations together in a transaction. Removing an allocation leaves its category and transactions available. Deleting a budget cascades to its allocations and clears the budget reference on historical notifications.

`savings_goals` has many `savings_contributions`, which track positive allocations toward a goal. They record goal progress rather than executing bank transfers. `notifications` stores event type, optional related budget/category, title, message and read timestamp. Notification delivery remains backend work.

Money uses `NUMERIC(18,2)`, dates use `DATE`, and timestamps use `TIMESTAMPTZ`. UUID primary keys identify records. Composite foreign keys reject cross-user relationships and currency mismatches between accounts and transactions, and between goals and contributions. Transactions store signed amounts. Expenses are negative, income and refunds are positive, and transfers may have either sign. Amounts must be nonzero and finite. Queries must keep currencies separate.

## 6. Reporting views

- `budget_category_spending` returns category allocation, posted actual spending and remaining allowance for a budget month.
- `budget_group_spending` adds the category-group totals used by the UI.
- `monthly_cash_flow` groups posted income and spending by user, month, scope and currency.
- `savings_goal_progress` sums goal contributions and calculates the remaining target amount.

Pending, removed and transfer transactions do not count toward spending or cash-flow totals. Refunds reduce spending in the month they post. Budget views include allocated categories. Dashboard totals should use `monthly_cash_flow` to also include uncategorized spending and categories omitted from a plan. Forecasts and CSV reports can use the stored transaction history and views. Backend queries must explicitly filter by user, period, scope and currency.

Disconnect a bank by setting its connection status to `disconnected`. Stop future sync for that connection while retaining accounts and transactions. Foreign keys prevent deletion of a connection with retained accounts. Account balances are snapshots from the bank or manual input and may differ from incomplete transaction history. The backend must serialize account-limit checks, reconcile imports, enforce permissions, validate category scope and validate allocation totals when saving a plan.

## 7. Existing volumes, production and persistence

The schema and seed commands work with an existing Docker volume. They are explicit initialization steps after startup. There is no dependency on PostgreSQL's first-boot initialization directory, and no volume reset is required. `docker compose down` preserves database data. Avoid `docker compose down -v` unless intentionally deleting all local database data.

For production, validate and start the production configuration, then apply the schema only.

```bash
docker compose -f compose.yaml -f compose.prod.yaml config --quiet
docker compose -f compose.yaml -f compose.prod.yaml up -d --build
docker compose -f compose.yaml -f compose.prod.yaml \
  exec database pg_isready -U seng513 -d seng513
docker compose -f compose.yaml -f compose.prod.yaml \
  exec -T database psql -U seng513 -d seng513 \
  -v ON_ERROR_STOP=1 < database/schema.sql
```

Do not load the development seed into a production database. Use external production secrets and a restricted application database role. The existing local Compose configuration uses its configured database owner for development. Plan database backups and migrations before later production changes.

If PostgreSQL is installed locally, the equivalent setup uses an existing empty database and a libpq connection URL. Keep credentials outside shell history by configuring a password file or your environment separately.

```bash
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f database/schema.sql
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f database/seed.sql
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f database/verify.sql
```

## 8. Submission

The archive `output/seng513-schema-pg-8.zip` contains the SQL scripts, these README instructions, the root README, the PDF, Compose files, `.env.example` and backend files needed to run the setup. Create a local `.env` from the template after extracting. The archive excludes real secrets, dependencies and Git metadata.

Commit the milestone files and create the `schema-milestone` tag at the reviewed commit. Publish the commit and tag to GitLab when ready.

```bash
git push origin main
git push origin schema-milestone
```

Upload the ZIP to the Database Schema and Seeding Script Dropbox in D2L. The PDF is a copy of these instructions. Confirm that GitLab shows `schema-milestone` at the intended commit and that the D2L upload completes.

## Design references

The model follows the FinClear group proposal and the UI Design Figma file at https://www.figma.com/design/Ffw3oqQvPKw1p9HroxhH4k/UI-Design . The October fixtures follow the monthly plan and business-report examples in the design. Scripts provide data storage and reporting foundations for the full proposal scope. Feature endpoints and external-service integrations are implemented separately by the application team.
